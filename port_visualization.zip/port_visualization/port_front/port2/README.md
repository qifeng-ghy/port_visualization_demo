# port2

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


### 引入CSS

<style scoped>

@import url(../css/common.css);
@import url(../css/map.css);

</style>

### 引入自创JS文件
例：
import {china} from "../js/china";
china();